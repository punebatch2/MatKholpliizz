package com.capstore.admin.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import javax.persistence.JoinColumn;
@Entity
@Table(name="merchantdetail")
public class MerchantDTO {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="merchantid")
	private int merchantId;
	@Column(name="merchantname")
	private String merchantName;
	@Column(name="email")
	private String email;
	@Column(name="address")
	private String address;
	@Column(name="storename")
	private String storeName;
	@Column(name="mobileno")
	private String mobileNo;
	@Column(name="merchantrating")
	private double merchantRating;
	@Column(name="merchantfeedback")
	private String merchantFeedback;
	
	public MerchantDTO() {
		// TODO Auto-generated constructor stub
	}
	
	public MerchantDTO(int merchantId, String merchantName, String email, String address, String storeName,
			String mobileNo, double merchantRating, String merchantFeedback, List<ProductDTO> products,
			List<OfferDTO> offers, List<OrderDTO> orders) {
		super();
		this.merchantId = merchantId;
		this.merchantName = merchantName;
		this.email = email;
		this.address = address;
		this.storeName = storeName;
		this.mobileNo = mobileNo;
		this.merchantRating = merchantRating;
		this.merchantFeedback = merchantFeedback;
		this.products = products;
		this.offers = offers;
		this.orders = orders;
	}



	@ManyToMany(cascade = { CascadeType.ALL })
    @JoinTable(
        name = "merchantproduct", 
        joinColumns = { @JoinColumn(name = "merchantid") }, 
        inverseJoinColumns = { @JoinColumn(name = "productid") }
    )
	private List<ProductDTO> products;
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy="merchants")
//	@JsonManagedReference("merchants")
	private List<OfferDTO> offers;
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy="merchants")
	//@JsonManagedReference("merchantorder")
	private List<OrderDTO> orders;
	@JsonIgnore
	public List<ProductDTO> getProducts() {
		return products;
	}
	public void setProducts(List<ProductDTO> products) {
		this.products = products;
	}
	
	public List<OfferDTO> getOffers() {
		return offers;
	}
	public void setOffers(List<OfferDTO> offers) {
		this.offers = offers;
	}
	
	public List<OrderDTO> getOrders() {
		return orders;
	}
	public void setOrders(List<OrderDTO> orders) {
		this.orders = orders;
	}
	public int getMerchantId() {
		return merchantId;
	}
	public void setMerchantId(int merchantId) {
		this.merchantId = merchantId;
	}
	public String getMerchantName() {
		return merchantName;
	}
	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getStoreName() {
		return storeName;
	}
	public void setStoreName(String storeName) {
		this.storeName = storeName;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public double getMerchantRating() {
		return merchantRating;
	}
	public void setMerchantRating(double merchantRating) {
		this.merchantRating = merchantRating;
	}
	public String getMerchantFeedback() {
		return merchantFeedback;
	}
	public void setMerchantFeedback(String merchantFeedback) {
		this.merchantFeedback = merchantFeedback;
	}
	
	
}
