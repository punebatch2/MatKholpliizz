package com.capstore.admin.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capstore.admin.model.OrderDTO;
import com.capstore.admin.repository.OrderRepository;




@RestController
@RequestMapping("api/v1/")
public class OrdersController {
	
	@Autowired
	private OrderRepository orderRepository;
	
	//view order list
		@RequestMapping(value = "orders/{merchantid}", method = RequestMethod.GET,consumes = MediaType.APPLICATION_JSON_VALUE)
		public List<OrderDTO> list(@PathVariable int merchantid) {
			return orderRepository.findorders(merchantid);
		}
}
