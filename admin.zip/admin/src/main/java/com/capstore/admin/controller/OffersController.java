package com.capstore.admin.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capstore.admin.model.OfferDTO;
import com.capstore.admin.repository.OfferRepository;

import java.util.List;

@RestController
@RequestMapping("api/v1/")
public class OffersController {
	@Autowired
	private OfferRepository offerRepository;
	
	    //view offer list
		@RequestMapping(value = "offers", method = RequestMethod.GET,consumes = MediaType.APPLICATION_JSON_VALUE)
		public List<OfferDTO> list() {
			return offerRepository.findAll();
		}
		
		//add offer
		@RequestMapping(value = "offers/addOffer", method = RequestMethod.POST,consumes = MediaType.APPLICATION_JSON_VALUE)
		public OfferDTO create(@RequestBody OfferDTO offer) {
			return offerRepository.saveAndFlush(offer);
		}
}
