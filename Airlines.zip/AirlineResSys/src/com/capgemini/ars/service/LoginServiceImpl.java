package com.capgemini.ars.service;



import com.capgemini.ars.bean.UserBean;
import com.capgemini.ars.dao.AirlineDAOImplement;
import com.capgemini.ars.dao.IAirlineDao;
import com.capgemini.ars.exception.AirlineException;


public class LoginServiceImpl implements ILoginService {

	
	IAirlineDao airlineDao = new AirlineDAOImplement();

	public IAirlineDao getAirlineDao() {
		return airlineDao;
	}

	public void setAirlineDao(IAirlineDao airlineDao) {
		this.airlineDao = airlineDao;
	}

	@Override
	public String isValidUserLogin(UserBean userDetails)
			throws AirlineException {

		return airlineDao.isValidUserLogin(userDetails);
	}

}
