package com.capgemini.ars.bean;

import java.io.Serializable;
import java.sql.Date;
import java.time.LocalDate;


public class FlightInformationBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private int flightNo;

	private String airline;

	private String deptCity;

	private String arrCity;

	private String deptDate;

	private String tempDeptDate;

	private String classType;

	private int passengers;

	private String ccno;

	private String email;

	private String arrDate;

	private String tempArrDate;

	private String deptTime;

	private String arrTime;

	private int firstSeats;

	private double firstSeatsFare;

	private int bussSeats;

	private double bussSeatsFare;

	public int getFlightNo() {
		return flightNo;
	}

	public void setFlightNo(int flightNo) {
		this.flightNo = flightNo;
	}

	public String getAirline() {
		return airline;
	}

	public void setAirline(String airline) {
		this.airline = airline;
	}

	public String getDeptCity() {
		return deptCity;
	}

	public void setDeptCity(String deptCity) {
		this.deptCity = deptCity;
	}

	public String getArrCity() {
		return arrCity;
	}

	public void setArrCity(String arrCity) {
		this.arrCity = arrCity;
	}

	public String getDeptDate() {
		return deptDate;
	}

	public void setDeptDate(String deptDate) {
		this.deptDate = deptDate;
	}

	public String getArrDate() {
		return arrDate;
	}

	public void setArrDate(String arrDate) {
		this.arrDate = arrDate;
	}

	public String getDeptTime() {
		return deptTime;
	}

	public void setDeptTime(String deptTime) {
		this.deptTime = deptTime;
	}

	public String getArrTime() {
		return arrTime;
	}

	public void setArrTime(String arrTime) {
		this.arrTime = arrTime;
	}

	public int getFirstSeats() {
		return firstSeats;
	}

	public void setFirstSeats(Integer firstSeats) {
		this.firstSeats = firstSeats;
	}

	public double getFirstSeatsFare() {
		return firstSeatsFare;
	}

	public void setFirstSeatsFare(Double firstSeatsFare) {
		this.firstSeatsFare = firstSeatsFare;
	}

	public int getBussSeats() {
		return bussSeats;
	}

	public void setBussSeats(Integer bussSeats) {
		this.bussSeats = bussSeats;
	}

	public double getBussSeatsFare() {
		return bussSeatsFare;
	}

	public void setBussSeatsFare(Double bussSeatsFare) {
		this.bussSeatsFare = bussSeatsFare;
	}

	public String getClassType() {
		return classType;
	}

	public void setClassType(String classType) {
		this.classType = classType;
	}

	public int getPassengers() {
		return passengers;
	}

	public void setPassengers(int passengers) {
		this.passengers = passengers;
	}

	public String getCcno() {
		return ccno;
	}

	public void setCcno(String ccno) {
		this.ccno = ccno;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getTempDeptDate() {
		return tempDeptDate;
	}

	public void setTempDeptDate(String tempDeptDate) {
		this.tempDeptDate = tempDeptDate;
	}

	public String getTempArrDate() {
		return tempArrDate;
	}

	public void setTempArrDate(String tempArrDate) {
		this.tempArrDate = tempArrDate;
	}

	@Override
	public String toString() {
		return "FlightInformationBean [flightNo=" + flightNo + ", airline="
				+ airline + ", deptCity=" + deptCity + ", arrCity=" + arrCity
				+ ", deptDate=" + deptDate + ", arrDate=" + arrDate
				+ ", deptTime=" + deptTime + ", arrTime=" + arrTime
				+ ", firstSeats=" + firstSeats + ", firstSeatsFare="
				+ firstSeatsFare + ", BussSeats=" + bussSeats
				+ ", BussSeatsFare=" + bussSeatsFare + "]";
	}

}
