package com.java.cg.airlinereservation.ui;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

import com.java.cg.airlinereservation.dto.AirlineReservationForm;
import com.java.cg.airlinereservation.dto.TravelClass;
import com.java.cg.airlinereservation.service.ValidationService;

public class AirlineClient {
	
	static Scanner scan = new Scanner(System.in);
	
	
	public static void main(String[] args) {
		
		AirlineClient client = new AirlineClient();
		client.displayMenu();
			
	}
	
	
	private void  displayMenu(){
		
		boolean validate=false;
		ValidationService service = new ValidationService();
		AirlineClient client = new AirlineClient();
		AirlineReservationForm form  = new AirlineReservationForm();
		
		while(true){
			System.out.println("Welcome to Airline Reservation");
			System.out.println("==============================");
			System.out.println("Please make a choice:");
			System.out.println("1: Book A Ticket");
			System.out.println("2: Cancel a Ticket");
			System.out.println("3: View a Ticket");
			System.out.println("4: Exit");
			
			int choice = scan.nextInt();
			
			switch(choice){
			case 1:
				do{
					form=client.takeUserInput();
					validate=service.validateForm(form);
				}while(validate==false);
				service.saveDetails(form);
				System.out.println("Your ticket id is: " + form.getTicketId());
				
			break;
			case 2:
				client.cancelTicket();
				break;
			case 3:
				//client.viewTicket(form);
				//AirlineClient client = new AirlineClient();
				System.out.println("Enter the ticket Id: ");
				int temp=scan.nextInt();
				client.displayDetails(temp);
				break;
			case 4:
				System.exit(0);
				
			default: 
				System.out.println("You have entered wrong choice");
			}
		}
		
	}
	
	/*private void viewTicket(AirlineReservationForm form) {
		AirlineClient client = new AirlineClient();
		System.out.println("Enter the ticket Id: ");
		int temp=scan.nextInt();
		client.displayDetails(temp);
		
		
	}
*/

	private void cancelTicket() {
		ValidationService service = new ValidationService();
		System.out.println("Enter the ticket No. to cancel the ticket: ");
		int temp = scan.nextInt();
		service.cancelTicket(temp);
		
	}


	public AirlineReservationForm takeUserInput(){
		
		
		
		System.out.println("Enter the details:");
		
		
		AirlineReservationForm form = new AirlineReservationForm();
		
		System.out.println("From Station: ");
		form.setFromStation(scan.next());
		System.out.println("To Station: ");
		form.setToStation(scan.next());
		
		System.out.println("Date of Journey: ");
		DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		form.setDate(LocalDate.parse(scan.next(), dateFormat));
		
		System.out.println("OneWay(Y/N)?:");
		char c= scan.next().charAt(0);
		if(c=='Y'||c=='y'){
			form.setOneWay(true);
		}
		else{
			form.setOneWay(false);
			System.out.println("Enter Return Date:");
			form.setReturnDate(LocalDate.parse(scan.next(),dateFormat));
		}
		System.out.println("Enter the number of passengers");
		form.setNoOfPassengers(Integer.parseInt(scan.next()));
		
		
		boolean flag=false;
		do{
		System.out.println("Enter Travel Class (Economy/Business/PrivateJet):");
		String travelClass=scan.next().toUpperCase();

		switch(travelClass){
			case "ECONOMY":
				form.setTravelClass(TravelClass.ECONOMY);
				flag=true;
			break;
			case "BUSINESS":
				form.setTravelClass(TravelClass.BUSINESS);
				flag=true;
			break;
			case "PRIVATEJET":
				form.setTravelClass(TravelClass.PRIVATEJET);
				flag=true;
			break;
			default:
				System.out.println("Please enter a valid value");
				flag=false;
		}
		}while(flag==false);
		return form;
	}
	
	public void displayDetails(int ticketId){
		ValidationService service = new ValidationService();
		AirlineReservationForm form = (AirlineReservationForm) service.getTicket(ticketId);
		
		System.out.println("Your Details are:");
		System.out.println("Ticket id is: " + form.getTicketno());
		System.out.println("From Station: "+ form.getFromStation());
		System.out.println("To Station:" + form.getToStation());
		System.out.println("Date of Journey: "+ form.getDate());
		System.out.println("One Way?" + form.isOneWay());
		if(!form.isOneWay()){
			System.out.println("Return Date: " + form.getReturnDate());
		}
		System.out.println("Travel Class: "+ form.getTravelClass() );
		System.out.println("No of Passwengers: " + form.getNoOfPassengers());
	}
	
	
}
