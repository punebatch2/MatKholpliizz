package com.java.cg.airlinereservation.dto;

public enum TravelClass {
		ECONOMY, BUSINESS, PRIVATEJET

}
