package com.java.cg.airlinereservation.dao;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

import com.java.cg.airlinereservation.dto.AirlineReservationForm;


public class AirlineDao {
	
	static ObjectOutputStream os;
	public void addToMap(AirlineReservationForm form){
		int ticketid = form.getTicketId();
		String str= "D:/";
		String str2= str+ticketid+".txt";
		try {
			os = new ObjectOutputStream(new FileOutputStream(str2));
			os.writeObject(form);
			os.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void removeFromMap(int key){
	
		String str= "D:/";
		String str2= str+key+".txt";

		try {
			Files.deleteIfExists(Paths.get(str2));
		} catch (IOException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	
		System.out.println("Ticket cancellation is successfull");
	}
	public Object getObject(int key){
		String str= "D:/";
		String str2= str+key+".txt";
		try {
			ObjectInputStream s;
			s = new ObjectInputStream(new FileInputStream(str2));
			Object obj = s.readObject();
			s.close();
			return obj;
		} catch (ClassNotFoundException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
}
