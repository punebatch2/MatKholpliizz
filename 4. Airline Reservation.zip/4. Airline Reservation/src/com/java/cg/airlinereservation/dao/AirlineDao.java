package com.java.cg.airlinereservation.dao;

import java.util.HashMap;
import java.util.Map;

import com.java.cg.airlinereservation.dto.AirlineReservationForm;

public class AirlineDao {
	static Map map = new HashMap();
	
	public void addToMap(AirlineReservationForm form){
		map.put(form.getTicketId(), form);
	}
	public void removeFromMap(int key){
		map.remove(key);
		System.out.println("Ticket cancellation is successfull");
	}
	public Object getObject(int key){
		return map.get(key);
	}
}
