package com.java.cg.airlinereservation.dto;

import java.time.LocalDate;

public class AirlineReservationForm {
	private static int ticketId=100000;

	private String fromStation;
	private String toStation;
	private LocalDate date;
	private LocalDate returnDate;
	private int noOfPassengers;
	private TravelClass travelClass;
	private boolean isOneWay;
	
	public static int getTicketId() {
		return ticketId;
	}
	public static void setTicketId(int ticketId) {
		AirlineReservationForm.ticketId = ticketId;
	}
	public String getFromStation() {
		return fromStation;
	}
	public void setFromStation(String fromStation) {
		this.fromStation = fromStation;
	}
	public String getToStation() {
		return toStation;
	}
	public void setToStation(String toStation) {
		this.toStation = toStation;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public LocalDate getReturnDate() {
		return returnDate;
	}
	public void setReturnDate(LocalDate returnDate) {
		this.returnDate = returnDate;
	}
	public int getNoOfPassengers() {
		return noOfPassengers;
	}
	public void setNoOfPassengers(int noOfPassengers) {
		this.noOfPassengers = noOfPassengers;
	}
	public TravelClass getTravelClass() {
		return travelClass;
	}
	public void setTravelClass(TravelClass travelClass) {
		this.travelClass = travelClass;
	}
	public boolean isOneWay() {
		return isOneWay;
	}
	public void setOneWay(boolean isOneWay) {
		this.isOneWay = isOneWay;
	}

}
