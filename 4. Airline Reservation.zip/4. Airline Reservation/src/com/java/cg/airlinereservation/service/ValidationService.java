package com.java.cg.airlinereservation.service;

import java.time.LocalDate;

import com.java.cg.airlinereservation.dao.AirlineDao;
import com.java.cg.airlinereservation.dto.AirlineReservationForm;

public class ValidationService {
	
	AirlineDao dao =new AirlineDao();
	public boolean validateForm(AirlineReservationForm form){
		
		if(validateStation(form)&&validateDate(form)&&validatePassenger(form)){
			int temp = form.getTicketId();
			form.setTicketId(++temp);
			return true;
		}
		else{
			return false;
		}
	}

	private boolean validatePassenger(AirlineReservationForm form) {
		// TODO Auto-generated method stub
		if(form.getNoOfPassengers()<1){
			System.out.println("No. of passengers should be greater than or equal to 1");
			return false;
		}
		return true;
	}

	private boolean validateDate(AirlineReservationForm form) {
		// TODO Auto-generated method stub
		LocalDate date1= form.getDate();
		LocalDate date2= form.getReturnDate();
		
		
		if(!form.isOneWay()){
			if(date1.isAfter(date2)){
				System.out.println("Start date should be after the return date");
				return false;
			}
		}
		if(date1.isBefore(LocalDate.now())&& !date1.isEqual(LocalDate.now())){
			System.out.println("Start date can't be before the current date");
			return false;
		}
		return true;
		
	}

	private boolean validateStation(AirlineReservationForm form) {
		// TODO Auto-generated method stub
		String str1 = form.getFromStation();
		String str2 = form.getToStation();
		if(str1.equals(str2)){
			System.out.println("From Station and To Station can't be equal");
			return false;
		}
		return true;
	}
	
	public void saveDetails(AirlineReservationForm form){
		dao.addToMap(form);
	}
	public void cancelTicket(int ticketId){
		dao.removeFromMap(ticketId);
	}
	public Object getTicket(int ticketid){
		return dao.getObject(ticketid);
	}
}
